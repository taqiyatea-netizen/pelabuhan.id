# Untuk Ka Sausan 💌

Halaman web statis (satu file `index.html`, semua gambar & audio sudah tertanam).

## Cara jalankan di GitHub Pages
1. Buat repository baru di GitHub (mis. `untuk-ka-sausan`).
2. Upload `index.html`, `.nojekyll`, dan `README.md` ke branch `main`.
3. Buka **Settings → Pages**.
4. Di **Build and deployment**, pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, lalu **Save**.
5. Tunggu 1–2 menit. Link: `https://USERNAME.github.io/NAMA-REPO/`
